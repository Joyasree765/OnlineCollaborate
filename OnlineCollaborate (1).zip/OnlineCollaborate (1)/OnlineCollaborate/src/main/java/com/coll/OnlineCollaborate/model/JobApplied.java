package com.coll.OnlineCollaborate.model;

public class JobApplied {

}
